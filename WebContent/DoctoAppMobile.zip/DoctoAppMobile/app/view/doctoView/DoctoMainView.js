Ext.define('DoctoApp.view.doctoView.DoctorMainView', {
	extend : 'Ext.Panel',
	xtype: 'DoctoMainView',
	config : {
		itemId : [
		          {
		        	  
		          },
		
		]
	}
});