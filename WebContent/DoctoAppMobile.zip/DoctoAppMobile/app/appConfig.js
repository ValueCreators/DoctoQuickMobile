var config = {
	'serviceURL' : 'http://192.168.1.8:8080/doctowebservice/DoctoWebService'
}